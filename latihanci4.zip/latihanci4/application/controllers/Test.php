<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('mdata');
        $this->load->helper('url', 'anchor');
    }

    function coba()
    {
        $data['tabelsiswa'] = $this->mdata->ambil_data()->result();
        $this->load->view('vsiswa.php', $data);
    }

    function tambah()
    {
        $this->load->view('vtambah');
    }

    function aksitambah()
    {
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        

        $data = array(
            'nim' => $nim,
            'nama' => $nama,
            'alamat' => $alamat,
            
        );
        $this->mdata->tambah_data($data, 'tabelsiswa');
        redirect('test/coba');
    }

    function hapus ($nim)
{
$where = array('nim' => $nim);
$this->mdata->hapus_data($where, 'tabelsiswa');
redirect('test/coba');
}

function edit($nim)
{
    $where = array('nim' => $nim);
    $data['tabelsiswa'] = $this->mdata->edit_data($where, 'tabelsiswa')->result();
    $this->load->view('vedit', $data);
}

function update()
{
    $nim = $this->input->post('nim');
    $nama = $this->input->post('nama');
    $alamat = $this->input->post('alamat');

    $data = array(
        'nama' => $nama,
        'alamat' => $alamat
    );

    $where = array(
        'nim' => $nim
    );

    $this->mdata->update_data($where, $data, 'tabelsiswa');
    redirect('test/coba');
    
}

}