<!DOCTYPE html>
<html>

<head>
    <title>Membuat CRUD dengan CodeIgniter</title>
</head>

<body>
    <center>
        <h1>Membuat CRUD dengan CodeIgniter</title>
        <h3>Edit Data</h3>
</center>
<?php foreach ($tabelsiswa as $tbsiswa) { ?>
    <form action="<?php echo base_url() . 'test/update'; ?>" method="post">
    <table style="margin:20px auto;">
    <tr>
        <td>Nama</td>
        <td>
            <input type="hidden" name="nim" value="<?php echo $tbsiswa->NIM ?>">
            <input type="text" name="nama" value="<?php echo $tbsiswa->NAMA?>">
</td>
</tr>
<tr>
    <td>Alamat</td>
    <td><input type="text" name="alamat" value="<?php echo $tbsiswa->ALAMAT ?>"></td>
</tr>
<tr>
    <td></td>
    <td><input type="submit" value="Simpan"></td>
</tr>
</table>
</form>
<?php } ?>

</body>

</html>


}