<!DOCTYPE html>
<html>

<head>
    <title>Menghubungkan codeigniter dengan database mysql</title>
</head>

<body>
    <center>
        <h1>DATA MAHASISWA BARU</h1>
        <?php echo anchor('test/tambah', 'Tambah Data'); ?>
        <table border="1">
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
            <?php
            $no = 1;
            foreach ($tabelsiswa as $tbsiswa) { ?>
                <tr>
                    <td><?php echo $tbsiswa->NIM ?></td>
                    <td><?php echo $tbsiswa->NAMA ?></td>
                    <td><?php echo $tbsiswa->ALAMAT ?></td>
                    <td>
                        <?php echo anchor('test/edit/' . $tbsiswa->NIM, 'Edit'); ?>
                        <?php echo anchor('test/hapus/' . $tbsiswa->NIM, 'Hapus'); ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </center>
</body>

</html>